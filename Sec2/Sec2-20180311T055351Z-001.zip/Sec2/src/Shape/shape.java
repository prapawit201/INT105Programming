
package Shape;
//interface ไม่มีโค้ด
public interface /*abstract class*/ shape {
//        private String color;
//
//    public shape(String color) {
//        this.color = color;
//    }
//    
//    public final String getColor() {
//        return color;
//    }
//    
    public abstract double getArea() ;
    
    public abstract double getperimeter() ;
        

    //วิธีที่1
//    public double getArea(){
//        return  0 ;
//       
//    }
//    public double getPerimeter(){
//        return  0 ;
//       
//   }
    
    //วิธีที่2
  
    
//    @Override
//    public String toString() {
//        return "shape{" + "color=" + color + '}';
//    }
    //abstract ังคับให้ทำ
    //final บังคับไม่ให้เเก่ไข
    //final ทำให้เเก้ไขอะไรม่ได้
}

