/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package int105.SelfBmi;

/**
 *
 * @author Tisanai.Cha
 */
public class StudentBMI {

    public static String[] bmiStudents(Student std[]) {
        String[] temp = new String[std.length];
        for (int i = 0; i < std.length; i++) {
            temp[i] = bmiCategory(std[i]);
        }
        return temp;
    }

    public static String bmiCategory(Student std) {
        double bmi = calBmi(std);
        if (bmi < 0) {
            return "none";
        } else if (bmi < 18.5) {
            return "under weight";
        } else if (bmi < 25) {
            return "normal weight";
        } else if (bmi < 30) {
            return "over weight";
        } else {
            return "obesity";
        }

    }

    public static double calBmi(Student std) {
        if (std.getHeight() == 0) {
            return -2;
        }
        if (std.getHeight() < 0 || std.getWeight() < 0) {
            return -1;
        }
        return std.getWeight() / Math.pow(std.getHeight(), 2);
    }
}
