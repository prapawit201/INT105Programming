/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package int105.CountText;

/**
 *
 * @author Tisanai.Cha
 */
public class CountText {

    public static void main(String[] args) {
        String sentence = "Java application";
        char[] char4count = {'a', 'I', 'c'};
        int[] frequency = countCharInText(sentence, char4count);
        for (int i = 0; i < char4count.length; i++) {
            System.out.println("number of character " + char4count[i] + " is " + frequency[i]);
        }

    }

    public static int[] countCharInText(String text, char[] givenChars) {
        int[] counText = new int[givenChars.length];
        for (int j = 0; j < givenChars.length; j++) {
            for (int i = 0; i < text.length(); i++) {
                if ((givenChars[j] + "").toLowerCase().equalsIgnoreCase(text.charAt(i) + "")) {
                    counText[j]++;
                }
            }
        }
        return counText;
    }
}
